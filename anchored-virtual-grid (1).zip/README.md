## Difficulty explanation
Variable-height virtualization with scroll anchoring needs a measurement feedback loop (observer, layout effect, offset index) that stays stable while rows, sort, filter, selection, focus and edits all change. The usual fixes (fixed row heights, position-based state) break exactly where this task checks.

## Solution explanation
The reference keeps a Fenwick tree of measured row heights over the sorted/filtered id array, anchors scroll position on a record id plus pixel offset, and re-applies it in a layout effect whenever order or measurements change. Selection, focus and edit state are keyed by record id, and the active and edited rows are pinned in the DOM.

## Verification explanation
A Playwright suite builds the app around the submitted grid directory in a separate verifier image and checks DOM, scroll geometry, focus and the host app's data through the documented test hooks. The reward is 1 only if every scenario passes.

## Relevant experience
I have analyzed software codebases to diagnose bugs and application failures, and assessed proposed fixes for correctness, reliability and maintainability. My work has covered database transactions, asynchronous job processing, error handling and system recovery. I have reviewed code changes with a focus on edge cases such as retries and concurrent operations, and judged solutions against automated tests and defined engineering requirements.
